from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from datetime import datetime
from app.models import Item
from app.models import View_announcements
from app.models import ArchiveMaterial
from app.models import ManagingDependent
from app.models import Communication
from app.forms import CommunicationForm
from app.models import ActivityAnnouncement,Participant

# Create your views here.

@login_required
def additemform(request):
    context = {
        'title': 'Add Item Form',
        'year': datetime.now().year,
    }
    context['user'] = request.user

    return render(request,'additem/additemform.html',context)

def additemconfirmation(request):

    newitem_id = request.POST['item_id']
    newitem_name= request.POST['item_name']
    newitem_description = request.POST['item_description']

    newitem = Item(item_id = newitem_id,item_name = newitem_name, item_description =
        newitem_description)
    newitem.save()

    context = {

        'item_id': newitem_id,
        'item_name': newitem_name,
        'item_description': newitem_description,
    }
    return render(request,'additem/additemconfirmation.html',context)


def view_announcements(request):
    # Retrieve all announcements from the database
    announcements = View_announcements.objects.all()

    # Pass the announcements to the template context
    context = {'announcements': announcements}
    
    return render(request, 'additem/view_announcements.html', context)

def view_archive_materials(request):
    # Add logic to retrieve and display archive mater
    archive_materials = ArchiveMaterial.objects.all()
    # This is a placeholder, and you need to replace it with your actual logic
    context = {'archive_materials': archive_materials}
    

    return render(request, 'additem/view_archive_materials.html', context)


def view_dependents(request):
    # Add logic to retrieve and display the list of dependents (children)
    dependents = ManagingDependent.objects.all()

    # Implement search functionality if needed
    search_query = request.GET.get('search', '')
    if search_query:
        dependents = dependents.filter(name__icontains=search_query)

    return render(request, 'additem/view_dependents.html', {'dependents': dependents, 'search_query': search_query})

def communication_management(request):
    if request.method == 'POST':
        form = CommunicationForm(request.POST)
        if form.is_valid():
            form.instance.sender = request.user
            form.save()
            return redirect('communication_management')
    else:
        form = CommunicationForm()

    communications = Communication.objects.filter(sender=request.user)

    return render(request, 'additem/communication_management.html', {'form': form, 'communications': communications})

def activities_management(request):
    activities_list = ActivityAnnouncement.objects.all()
    return render(request, 'additem/activities_management.html', {'activities_list': activities_list})

def participate_activity(request, activity_id):
    activity = ActivityAnnouncement.objects.get(pk=activity_id)

    if request.method == 'POST':
        # Check if the user has already participated
        if not Participant.objects.filter(user=request.user, activity=activity).exists():
            participant = Participant(user=request.user, activity=activity)
            participant.save()
            messages.success(request, 'Successfully participated in the activity!')
        else:
            messages.warning(request, 'You have already participated in this activity.')

        return redirect('activities_management')

    return render(request, 'additem/participate_activity.html', {'activity': activity})

def participants_list(request, activity_id):
    activity = ActivityAnnouncement.objects.get(pk=activity_id)
    participants = Participant.objects.filter(activity=activity)
    return render(request, 'additem/participants_list.html', {'activity': activity, 'participants': participants})

def calendar_integration(request):
    # Add logic to retrieve and display a list of PTA events
    events = [
        {'event_id': 1, 'title': 'PTA Meeting', 'date': '2024-02-01'},
        {'event_id': 2, 'title': 'School Open House', 'date': '2024-02-10'},
        # Add more events as needed
    ]

    return render(request, 'additem/calendar_integration.html', {'events': events})

# additem/views.py
from django.http import HttpResponse

# Other imports as needed

def sync_to_calendar(request, event_id):
    # Add logic to sync the selected event to the chosen calendar app
    # You may use third-party libraries or APIs for calendar integration

    return HttpResponse(f'Event with ID {event_id} synced to the calendar app.')
