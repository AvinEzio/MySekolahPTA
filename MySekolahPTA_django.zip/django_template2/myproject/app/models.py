"""
Definition of models.
"""

from django.db import models

from django.contrib.auth.models import User

#sharing entity

class Item(models.Model):
    item_id = models.CharField(primary_key=True, max_length=10)
    item_name = models.TextField()
    item_description = models.TextField(null=True,default=None, blank=True)
    def __str__(self):
        return str(self.item_id)
    
class View_announcements(models.Model):
    title = models.CharField(max_length=255)
    content = models.TextField()
    pub_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class ArchiveMaterial(models.Model):
    date = models.DateField()
    type = models.CharField(max_length=255)
    content = models.TextField()

    def __str__(self):
        return f"{self.type} - {self.date}"
    
class ManagingDependent(models.Model):
    child_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    grade = models.CharField(max_length=50)
    age = models.IntegerField(default=0)  # Specify a default value

    def __str__(self):
        return f"{self.name} - {self.grade}"
    
class Communication(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_messages')
    subject = models.CharField(max_length=255)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_appointment = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender} to {self.recipient} - {self.subject}"
    
class ActivityAnnouncement(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    date = models.DateField()
    location = models.CharField(max_length=255)

    def __str__(self):
        return self.title
    
class Participant(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    activity = models.ForeignKey(ActivityAnnouncement, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.user.username} - {self.activity.title}"