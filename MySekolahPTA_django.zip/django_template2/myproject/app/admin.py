from django.contrib import admin
from app.models import Item

admin.site.register(Item)

from app.models import View_announcements
from app.models import ArchiveMaterial
from app.models import ManagingDependent
from app.models import Communication
from app.models import ActivityAnnouncement
admin.site.register(View_announcements)
admin.site.register(ArchiveMaterial)
admin.site.register(ManagingDependent)
admin.site.register(Communication)
admin.site.register(ActivityAnnouncement)
