"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path
from app import views as main_views
import django.contrib.auth.views
from django.contrib.auth.views import LoginView, LogoutView
from datetime import datetime

from additem import views as additem_views



admin.autodiscover()

urlpatterns = [
    path('admin/', admin.site.urls),
    re_path(r'^$', main_views.home, name='home'),
    re_path(r'^contact$', main_views.contact, name='contact'),
    re_path(r'^about$', main_views.about, name='about'),
    re_path(r'^login/$',
        LoginView.as_view(template_name = 'app/login.html'),
        name='login'),
    re_path(r'^logout$',
        LogoutView.as_view(template_name = 'app/index.html'),
        name='logout'),
    re_path(r'^menu$', main_views.menu, name='menu'),
    re_path(r'^view_announcements$', additem_views.view_announcements, name='additem/view_announcements.html'),
    re_path(r'^additemform$', additem_views.additemform, name='additem_form'),
    re_path(r'^additemconfirmation$', additem_views.additemconfirmation, name='additem_confirmation'),
    re_path(r'^view_archive_materials$', additem_views.view_archive_materials, name='view_archive_materials'),
    re_path(r'^view_dependents/$', additem_views.view_dependents, name='view_dependents'),
    re_path(r'^communication_management/$', additem_views.communication_management, name='communication_management'),
    re_path(r'^activities_management/$', additem_views.activities_management, name='activities_management'),
    re_path(r'^participate_activity/(?P<activity_id>\d+)/$', additem_views.participate_activity, name='participate_activity'),
    re_path(r'^participants_list/(?P<activity_id>\d+)/$', additem_views.participants_list, name='participants_list'),
     re_path(r'^calendar_integration/$', additem_views.calendar_integration, name='calendar_integration'),
    re_path(r'^sync_to_calendar/(?P<event_id>\d+)/$', additem_views.sync_to_calendar, name='sync_to_calendar'),
]
   


